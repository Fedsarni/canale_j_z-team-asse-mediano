package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import entity.EntityUtenteRegistrato;
import exception.DAOException;
import exception.DBConnectionException;

public class UtenteRegistratoDAO {
	public static void createUtenteRegistrato(EntityUtenteRegistrato eU) throws DAOException, DBConnectionException
	{
		
		try
		{
			PreparedStatement stmt = null;
			Connection conn = DBManager.getConnection();
			String query = "INSERT INTO `UtentiRegistrati` (`Email`, `Cognome`, `Nome`, `NrTelefono`) VALUES (?,?,?,?);";
			
			try
			{
				stmt = conn.prepareStatement(query);
				
				stmt.setString(1, eU.getEmail());
				stmt.setString(2, eU.getCognome());
				stmt.setString(3, eU.getNome());
				stmt.setString(4, eU.getNumeroTelefono());
				
				stmt.executeUpdate();
				
			}catch(SQLException e) {
				throw new DAOException("Errore registrazione utente");
			} finally {
				if (stmt != null)
				{
				    try {
				      stmt.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura dello Statement");
				    }
				DBManager.closeConnection();
				}
			}
		} catch(SQLException e) {
			throw new DBConnectionException("Errore connessione database");
		}
	}
	
	public static boolean ricercaUtenteRegistrato(String Email) throws DAOException, DBConnectionException
	{
		boolean trovato=false;
		
		try
		{
			PreparedStatement stmt = null;
			ResultSet result = null;
			Connection conn = DBManager.getConnection();
			String query = "SELECT * FROM `UtentiRegistrati` WHERE `Email`=?;";
			
			try
			{
				stmt = conn.prepareStatement(query);
				
				stmt.setString(1, Email);
				
				result=stmt.executeQuery();
				if(result.next())
					{
						trovato=true;
						System.out.println("Abbiamo trovato l'utente registrato");
					}
				
			}catch(SQLException e) {
				throw new DAOException("Errore registrazione utente");
			} finally {
				if (result != null) {
				    try {
				      result.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura del ResultSet");
				    }
				  }

				  if (stmt != null) {
				    try {
				      stmt.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura dello Statement");
				    }
				  }
				DBManager.closeConnection();
			}
		} catch(SQLException e) {
			throw new DBConnectionException("Errore connessione database");
		}
		return trovato;
	}
}