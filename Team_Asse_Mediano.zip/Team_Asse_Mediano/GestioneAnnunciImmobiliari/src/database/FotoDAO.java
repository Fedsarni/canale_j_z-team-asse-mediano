package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.EntityFoto;
import exception.DAOException;
import exception.DBConnectionException;

public class FotoDAO
{
	public static void createFoto(EntityFoto eF) throws DAOException, DBConnectionException
	{
		
		PreparedStatement stmt = null;
		String query = "SHOW TABLE STATUS LIKE 'Annunci';";
		ResultSet result = null;
		try
		{
			Connection conn = DBManager.getConnection();
			
			try
			{
				stmt = conn.prepareStatement(query);
				
				result=stmt.executeQuery();
				if(result.next())
					eF.setID((int) result.getLong(11));
				
				query = "INSERT INTO `Fotografie` (`Id`, `URL`, `IdAnnuncio`) VALUES (NULL,?,?);";
				stmt.close();
				stmt = conn.prepareStatement(query);
				stmt.setString(1, eF.getURL());
				stmt.setInt(2, eF.getAnnuncio().getID());
					
				stmt.executeUpdate();
				
			}catch(SQLException e) {
				throw new DAOException("Errore pubblicazione foto...");
			} finally {
				if (result != null) {
				    try {
				      result.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura del ResultSet");
				    }
				  }

				  if (stmt != null) {
				    try {
				      stmt.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura dello Statement");
				    }
				  }
				DBManager.closeConnection();
			}
		} catch(SQLException e) {
			throw new DBConnectionException("Errore connessione database");
		}
	}
}