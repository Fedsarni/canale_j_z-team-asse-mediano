package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import entity.EntityAnnuncio;
import entity.EntityInserzionista;
import exception.DAOException;
import exception.DBConnectionException;

public class AnnuncioDAO
{
	public static void createAnnuncio(EntityAnnuncio eA) throws DAOException, DBConnectionException
	{
		try
		{
			Connection conn = DBManager.getConnection();
			PreparedStatement stmt = null;
			ResultSet result = null;
			String query = "SHOW TABLE STATUS LIKE 'Annunci';";
			try
			{
				stmt = conn.prepareStatement(query);
				
				result = stmt.executeQuery();
				if(result.next())
				eA.setID((int) result.getLong(11));
				stmt.close();
				query = "INSERT INTO `Annunci` (`Identificativo`, `NrMetriQuadri`, `NrVani`, `Prezzo`, `CAP`, `Citta'`, `Tipologia`, `Descrizione`, `DataInserimento`, `UsernameInserzionista`, `Stato`) VALUES (NULL,?,?,?,?,?,?,?,?,?,?);";
				stmt = conn.prepareStatement(query);
				stmt.setFloat(1, eA.getNrMetriQuadri());
				stmt.setInt(2, eA.getNrVani());
				stmt.setFloat(3, eA.getPrezzo());
				stmt.setString(4, eA.getCAP());
				stmt.setString(5, eA.getCittà());
				stmt.setString(6, eA.getTipologia());
				stmt.setString(7, eA.getDescrizione());
				stmt.setDate(8, eA.getdataInserimento());
				stmt.setString(9, eA.getInserzionista().getUsername());
				stmt.setString(10, eA.getStato());
				
				stmt.executeUpdate();
				
				
			}catch(SQLException e) {
				throw new DAOException("Errore pubblicazione annuncio...");
			} finally {
				if (result != null) {
				    try {
				      result.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura del ResultSet");
				    }
				  }

				  if (stmt != null) {
				    try {
				      stmt.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura dello Statement");
				    }
				  }
				DBManager.closeConnection();
			}
		} catch(SQLException e) {
			throw new DBConnectionException("Errore connessione database");
		}
	}
	
	public static ArrayList<EntityAnnuncio> selectAnnunci(String Paese, int NrVani, String Tipologia) throws DAOException, DBConnectionException
	{
		ArrayList <EntityAnnuncio> Lista = new ArrayList<EntityAnnuncio>();
		
		String query = "SELECT * FROM `Annunci` a JOIN `Inserzionisti` i ON(a.`UsernameInserzionista`=i.`Username`)  WHERE ((`Citta'`=? OR `CAP`=?) AND `NrVani`=? AND `Tipologia`=?);";
		PreparedStatement stmt = null;
		ResultSet result = null;
		EntityInserzionista eI= null;
		try
		{
			Connection conn = DBManager.getConnection();
			
			try
			{
				stmt = conn.prepareStatement(query);
				
				stmt.setString(1, Paese);
				stmt.setString(2, Paese);
				stmt.setInt(3, NrVani);
				stmt.setString(4, Tipologia);
				
				result=stmt.executeQuery();
				while(result.next())
				{
				
					eI=new EntityInserzionista(result.getString(12), result.getString(13), result.getString(15), result.getString(14));
					Lista.add(new EntityAnnuncio(result.getInt(1), result.getString(8), result.getString(7), result.getString(6), result.getFloat(2), result.getInt(3), result.getString(4), result.getFloat(5), result.getString(9), eI));
				}
			}catch(SQLException e) {
				throw new DAOException("Errore ricerca annunci...");
			} finally {
				if (result != null) {
				    try {
				      result.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura del ResultSet");
				    }
				  }

				  if (stmt != null) {
				    try {
				      stmt.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura dello Statement");
				    }
				  }
				DBManager.closeConnection();
			}
		} catch(SQLException e) {
			throw new DBConnectionException("Errore connessione database");
		}
		return Lista;
	}

	public static boolean isNumeric(String str)
	{
		return str.matches("[0-9]+");
	}
}