package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.EntityInserzionista;
import exception.DAOException;
import exception.DBConnectionException;

public class InserzionistaDAO
{
	public static EntityInserzionista createInserzionista(String Username) throws DAOException, DBConnectionException
	{
		
		EntityInserzionista eI = null;
		try
		{
			Connection connInserzionista = DBManager.getConnection();
			String queryInserzionista = "SELECT * FROM `Inserzionisti` WHERE `Username`=?;";
			PreparedStatement stmtInserzionista = null;
			ResultSet resultInserzionista = null;
			try
			{
				stmtInserzionista = connInserzionista.prepareStatement(queryInserzionista);
				
				stmtInserzionista.setString(1, Username);
				
				resultInserzionista=stmtInserzionista.executeQuery();
				if(resultInserzionista.next())
					eI=new EntityInserzionista(resultInserzionista.getString(1), resultInserzionista.getString(2), resultInserzionista.getString(4), resultInserzionista.getString(3));
				
			}catch(SQLException e) {
				throw new DAOException("Errore registrazione utente");
			} finally {
				if (resultInserzionista != null) {
				    try {
				      resultInserzionista.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura del ResultSet");
				    }
				  }

				  if (stmtInserzionista != null) {
				    try {
				      stmtInserzionista.close();
				    } catch (SQLException e) {
				    	throw new DAOException("Errore di chiusura dello Statement");
				    }
				  }
				DBManager.closeConnection();
			}
		} catch(SQLException e) {
			throw new DBConnectionException("Errore connessione database");
		}
		return eI;
	}
}