package entity;

import exception.DAOException;
import exception.DBConnectionException;
import database.FotoDAO;

public class EntityFoto
{
	private int ID;
	private String URL;
	private EntityAnnuncio Annuncio;
	
	public EntityFoto()
	{
		super();
		ID = 0;
		URL = null;
		Annuncio = new EntityAnnuncio();
	}
	
	public EntityFoto(int ID, String URL, EntityAnnuncio Annuncio)
	{
		super();
		this.ID = ID;
		this.URL = URL;
		this.Annuncio = Annuncio;
	}
	
	public EntityFoto(String URL, EntityAnnuncio Annuncio)
	{
		super();
		ID = 0;
		this.URL = URL;
		this.Annuncio = Annuncio;
	}
	
	public int getID() {return ID;}
	public String getURL() {return URL;}
	public EntityAnnuncio getAnnuncio() {return Annuncio;}
	
	public void setID(int ID) {this.ID=ID;}
	public void setURL(String URL) {this.URL=URL;}
	public void setAnnuncio(EntityAnnuncio Annuncio) {this.Annuncio=Annuncio;}
	
	public void saveFoto() throws DAOException, DBConnectionException
	{
		FotoDAO.createFoto(this);
	}
}