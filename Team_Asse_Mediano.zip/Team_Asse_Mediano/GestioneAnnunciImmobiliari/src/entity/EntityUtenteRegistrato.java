package entity;

import database.UtenteRegistratoDAO;
import exception.DAOException;
import exception.DBConnectionException;

public class EntityUtenteRegistrato
{
	
	private String Nome;
	private String Cognome;
	private String NumeroTelefono;
	private String Email;
	
	public EntityUtenteRegistrato()
	{
		super();
		Nome=new String();
		Cognome=new String();
		NumeroTelefono=new String();
		Email=new String();
	}
	
	public EntityUtenteRegistrato(String Nome, String Cognome, String NumeroTelefono, String Email)
	{
		super();
		this.Nome=Nome;
		this.Cognome=Cognome;
		this.NumeroTelefono=NumeroTelefono;
		this.Email=Email;
	}
	
	public String getNome() {return Nome;}
	public String getCognome() {return Cognome;}
	public String getNumeroTelefono() {return NumeroTelefono;}
	public String getEmail() {return Email;}
	
	public void setNome(String Nome) {this.Nome=Nome;}
	public void setCognome(String Cognome) {this.Cognome=Cognome;}
	public void setNumeroTelefono(String NumeroTelefono) {this.NumeroTelefono=NumeroTelefono;}
	public void setEmail(String Email) {this.Email=Email;}
	
	public void saveUtenteRegistrato() throws DAOException, DBConnectionException
	{
		UtenteRegistratoDAO.createUtenteRegistrato(this);
	}
}