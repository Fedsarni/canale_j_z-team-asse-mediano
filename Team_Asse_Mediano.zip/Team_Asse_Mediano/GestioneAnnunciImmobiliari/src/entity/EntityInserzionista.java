package entity;

import database.InserzionistaDAO;
import exception.DAOException;
import exception.DBConnectionException;

public class EntityInserzionista
{
	
	private String Username;
	private String Password;
	private String RecapitoTelefonico;
	private String RecapitoEmail;
	
	public EntityInserzionista()
	{
		super();
		Username=new String();
		Password=new String();
		RecapitoTelefonico=new String();
		RecapitoEmail=new String();
	}
	
	public EntityInserzionista(String Username, String Password, String RecapitoTelefonico, String RecapitoEmail)
	{
		super();
		this.Username=Username;
		this.Password=Password;
		this.RecapitoTelefonico=RecapitoTelefonico;
		this.RecapitoEmail=RecapitoEmail;
	}
	
	public EntityInserzionista(String Username) throws DAOException, DBConnectionException
	{
		EntityInserzionista eI=InserzionistaDAO.createInserzionista(Username);
		this.Username=eI.getUsername();
		this.Password=eI.getPassword();
		this.RecapitoTelefonico=eI.getRecapitoTelefonico();
		this.RecapitoEmail=eI.RecapitoEmail;
	}
	
	public String getUsername() {return Username;}
	public String getPassword() {return Password;}
	public String getRecapitoTelefonico() {return RecapitoTelefonico;}
	public String getEmail() {return RecapitoEmail;}
	
	public void setUsername(String Username) {this.Username=Username;}
	public void setPassword(String Password) {this.Password=Password;}
	public void setRecapitoTelefonico(String RecapitoTelefonico) {this.RecapitoTelefonico=RecapitoTelefonico;}
	public void setEmail(String RecapitoEmail) {this.RecapitoEmail=RecapitoEmail;}
}