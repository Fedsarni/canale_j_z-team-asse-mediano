package entity;

import java.sql.Date;
import java.util.Calendar;

import exception.DAOException;
import exception.DBConnectionException;
import database.AnnuncioDAO;

public class EntityAnnuncio
{
	private int ID;
	private String Tipologia;
	private String Città;
	private String CAP;
	private float NrMetriQuadri;
	private int NrVani;
	private String Stato;
	private float Prezzo;
	private String Descrizione;
	private Date dataInserimento;
	private EntityInserzionista Inserzionista;
	
	public EntityAnnuncio()
	{
		super();
		ID = 0;
		Tipologia = new String();
		Città = new String();
		CAP = new String();
		NrMetriQuadri = 0;
		NrVani = 0;
		Stato = new String();
		Prezzo = 0;
		Descrizione = new String();
		Inserzionista = new EntityInserzionista();
		this.dataInserimento = GeneraDataAttuale();
	}
	
	public EntityAnnuncio(String Tipologia, String Città, String CAP, float NrMetriQuadri, int NrVani, String Stato, float Prezzo, String Descrizione, EntityInserzionista Inserzionista)
	{
		super();
		ID = 0;
		this.Tipologia = Tipologia;
		this.Città = Città;
		this.CAP = CAP;
		this.NrMetriQuadri = NrMetriQuadri;
		this.NrVani = NrVani;
		this.Stato = Stato;
		this.Prezzo = Prezzo;
		this.Descrizione = Descrizione;
		this.Inserzionista = Inserzionista;
		this.dataInserimento = GeneraDataAttuale();
	}
	
	public EntityAnnuncio(int ID, String Tipologia, String Città, String CAP, float NrMetriQuadri, int NrVani, String Stato, float Prezzo, String Descrizione, EntityInserzionista Inserzionista)
	{
		super();
		this.ID = ID;
		this.Tipologia = Tipologia;
		this.Città = Città;
		this.CAP = CAP;
		this.NrMetriQuadri = NrMetriQuadri;
		this.NrVani = NrVani;
		this.Stato = Stato;
		this.Prezzo = Prezzo;
		this.Descrizione = Descrizione;
		this.Inserzionista = Inserzionista;
		this.dataInserimento = GeneraDataAttuale();
	}
	
	public EntityAnnuncio(int ID, String Tipologia, String Città, String CAP, float NrMetriQuadri, int NrVani, String Stato, float Prezzo, String Descrizione, String UsernameInserzionista) throws DAOException, DBConnectionException
	{
		super();
		this.ID = ID;
		this.Tipologia = Tipologia;
		this.Città = Città;
		this.CAP = CAP;
		this.NrMetriQuadri = NrMetriQuadri;
		this.NrVani = NrVani;
		this.Stato = Stato;
		this.Prezzo = Prezzo;
		this.Inserzionista = new EntityInserzionista(UsernameInserzionista);
	}
	
	public int getID() {return ID;}
	public String getTipologia() {return Tipologia;}
	public String getCittà() {return Città;}
	public String getCAP() {return CAP;}
	public float getNrMetriQuadri() {return NrMetriQuadri;}
	public int getNrVani() {return NrVani;}
	public String getStato() {return Stato;}
	public float getPrezzo() {return Prezzo;}
	public String getDescrizione() {return Descrizione;}
	public Date getdataInserimento() {return dataInserimento;}
	public EntityInserzionista getInserzionista() {return Inserzionista;}
	
	public void setID(int ID) {this.ID=ID;}
	public void setTipologia(String Tipologia) {this.Tipologia=Tipologia;}
	public void setCittà(String Città) {this.Città=Città;}
	public void setCAP(String CAP) {this.CAP=CAP;}
	public void setNrMetriQuadri(float NrMetriQuadri) {this.NrMetriQuadri=NrMetriQuadri;}
	public void setNrVani(int NrVani) {this.NrVani=NrVani;}
	public void setStato(String Stato) {this.Stato=Stato;}
	public void setPrezzo(float Prezzo) {this.Prezzo=Prezzo;}
	public void setDescrizione(String Descrizione) {this.Descrizione=Descrizione;}
	public void setInserzionista(EntityInserzionista Inserzionista) {this.Inserzionista=Inserzionista;}
	
	public void saveAnnuncio() throws DAOException, DBConnectionException
	{
		AnnuncioDAO.createAnnuncio(this);
	}
	
	private Date GeneraDataAttuale()
	{
		Calendar calendar = Calendar.getInstance();
	    java.util.Date currentDate = calendar.getTime();
	    long currentTimeInMillis = currentDate.getTime();
	    Date sqlDate = new Date(currentTimeInMillis);
	    return sqlDate;
	}
}