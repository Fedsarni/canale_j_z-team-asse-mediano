package control;

import java.util.ArrayList;

import boundary.BoundaryInserzionista;
import entity.EntityUtenteRegistrato;
import entity.EntityInserzionista;
import entity.EntityAnnuncio;
import entity.EntityFoto;
import database.AnnuncioDAO;
import database.UtenteRegistratoDAO;
import exception.DAOException;
import exception.DBConnectionException;
import exception.EmptyListException;

public class GestioneAnnunciImmobiliari
{
	static boolean UtenteRegistrato = false;
	static EntityInserzionista Inserzionista = null; //login
	private String Telefono = null;
	private String Email = null;
	
	private static GestioneAnnunciImmobiliari gA = null;
	
	private GestioneAnnunciImmobiliari()
	{
		super();
	}
	
	public static GestioneAnnunciImmobiliari getInstance() 
	{ 
		if (gA == null) 
			gA = new GestioneAnnunciImmobiliari(); 

		return gA; 
	}
	
	public EntityUtenteRegistrato inserisciDatiUtente(String Nome, String Cognome, String Telefono, String Email)
	{
		return new EntityUtenteRegistrato(Nome, Cognome, Telefono, Email);
	}
	
	public void inviaConferma(EntityUtenteRegistrato eU) throws DAOException, DBConnectionException
	{
		eU.saveUtenteRegistrato();
	}
	
	public EntityAnnuncio inserisciDatiAnnuncio(String Tipologia, String Città, String CAP, float NrMetriQuadri, int NrVani, String Stato, float Prezzo, String Descrizione) throws DAOException, DBConnectionException
	{
		EntityInserzionista Inserzionista = new EntityInserzionista(BoundaryInserzionista.getUsername());
		return new EntityAnnuncio(Tipologia, Città, CAP, NrMetriQuadri, NrVani, Stato, Prezzo, Descrizione, Inserzionista);
	}
	
	public void confermaPubblicazione(EntityAnnuncio eA, ArrayList<EntityFoto> Fotografie) throws DAOException, DBConnectionException
	{
		try
		{
			eA.saveAnnuncio();
			for(int i=0;i<Fotografie.size();i++)
			{
				try
				{
					Fotografie.get(i).saveFoto();
				} catch (DAOException e)
				{
					e.getMessage();
				}
				catch (DBConnectionException e)
				{
					e.getMessage();
				}
			}
		} catch (DAOException e)
		{
			e.getMessage();
		}
		catch (DBConnectionException e)
		{
			e.getMessage();
		}
	}
	
	public ArrayList<EntityAnnuncio> ricercaAnnunci(String Paese, int NrVani, String Tipologia, String Email) throws DAOException, DBConnectionException
	{
		
		UtenteRegistrato=readUtenteRegistrato(Email);
		return AnnuncioDAO.selectAnnunci(Paese, NrVani, Tipologia);
	}
	
	private static boolean readUtenteRegistrato(String email) throws DAOException, DBConnectionException
	{
		return UtenteRegistratoDAO.ricercaUtenteRegistrato(email);
	}
	
	public void visualizzaDettagliLista(ArrayList<EntityAnnuncio> Lista) throws EmptyListException
	{
		if(Lista.size()==0)
			throw new EmptyListException("Lista Vuota!");
		for(int i=0;i<Lista.size();i++)
			{
				visualizzaDettagliAnnuncio(Lista.get(i));
				if(checkUtenteRegistrato())
					visualizzaRecapitiInserzionista(Lista.get(i));
				System.out.println("");
			}
	}
	
	public void visualizzaDettagliAnnuncio(EntityAnnuncio Annuncio)
	{
		System.out.println("ID: "+Annuncio.getID());
		System.out.println("Citta': "+Annuncio.getCittà());
		System.out.println("CAP: "+Annuncio.getCAP());
		System.out.println("Tipologia: "+Annuncio.getTipologia());
		System.out.println("Stato: "+Annuncio.getStato());
		System.out.println("Descrizione: "+Annuncio.getDescrizione());
		System.out.println("Vani: "+Annuncio.getNrVani());
		System.out.println("Metri quadri: "+Annuncio.getNrMetriQuadri());
		System.out.println("Prezzo: "+Annuncio.getPrezzo());
		System.out.println("Data inserimento: "+Annuncio.getdataInserimento());
		System.out.println("Username inserzionista: "+Annuncio.getInserzionista().getUsername());
	}
	
	public void visualizzaRecapitiInserzionista(EntityAnnuncio Annuncio)
	{
		trovaRecapitiInserzionista(Annuncio);
		System.out.println("Telefono: "+Telefono);
		System.out.println("Email: "+Email);
	}
	
	public void trovaRecapitiInserzionista(EntityAnnuncio Annuncio)
	{
		Telefono=Annuncio.getInserzionista().getRecapitoTelefonico();
		Email=Annuncio.getInserzionista().getEmail();
	}
	
	public boolean checkUtenteRegistrato()
	{
		return UtenteRegistrato;
	}
}