package boundary;

public class BoundaryUtenteRegistrato extends BoundaryUtente
{
	public static void iscrizioneNewsletter()
	{
		
	}
	
	public static void disiscrizioneNewsletter()
	{
		
	}
}