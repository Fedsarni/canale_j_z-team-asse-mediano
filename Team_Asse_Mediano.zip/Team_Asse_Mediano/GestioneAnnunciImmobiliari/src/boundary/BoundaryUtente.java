package boundary;

import java.util.Scanner;
import java.util.ArrayList;
import control.GestioneAnnunciImmobiliari;
import entity.EntityUtenteRegistrato;
import entity.EntityAnnuncio;
import exception.DAOException;
import exception.DBConnectionException;
import exception.EmptyListException;


public class BoundaryUtente
{
	static Scanner scan = new Scanner(System.in);
	
	public static void registrazioneUtente()
	{
		String Nome = null;
		String Cognome = null;
		String NumeroTelefono = null;
		String Email = null;
		boolean inputValido = false;
		GestioneAnnunciImmobiliari gestioneAnnunciImmobiliari=GestioneAnnunciImmobiliari.getInstance();
		
		try
		{
			while(!inputValido)
				{
				System.out.println("Inserire il nome:");
				Nome = scan.nextLine();
				if(isAlphabetic(Nome))
					if(Nome.length()<=30)
						inputValido=true;
					else System.out.println("Nome troppo lungo...");
				else System.out.println("Nome non valido...");
				}
			inputValido=false;
			
			while(!inputValido)
			{
			System.out.println("Inserire il cognome:");
			Cognome = scan.nextLine();
			if(isAlphabetic(Cognome))
				if(Cognome.length()<=30)
					inputValido=true;
				else System.out.println("Cognome troppo lungo...");
			else System.out.println("Cognome non valido...");
			}
			inputValido=false;
			
			while(!inputValido)
				{
					
					System.out.println("Inserire il numero di telefono:");
					NumeroTelefono = scan.nextLine();
					if(NumeroTelefono.length()==10 && isNumeric(NumeroTelefono))
						inputValido = true;
					else System.out.println("Numero di telefono non valido...");
				}
				inputValido=false;
				while(!inputValido)
				{
					System.out.println("Inserire la mail:");
					Email = scan.nextLine();
					if (Email.contains("@") && Email.contains(".")) {
						inputValido = true;
					} else {
						System.out.println("Email non valida..");
					}
				}
			EntityUtenteRegistrato UtenteRegistrato=gestioneAnnunciImmobiliari.inserisciDatiUtente(Nome, Cognome, NumeroTelefono, Email);
			
			System.out.println("");
			System.out.println("Vuoi confermare la registrazione?");
			System.out.println("S: si'");
			String conferma = scan.nextLine();
			if (!conferma.equals("S") && !conferma.equals("s"))
			{
				System.out.println("Operazione annullata..");
				System.out.println();
				return; 
			}
			try
			{
				gestioneAnnunciImmobiliari.inviaConferma(UtenteRegistrato);
				System.out.println("Registrazione effettuata!");
			}
			catch(DAOException e)
			{
				System.out.println(e.getMessage());
				System.out.println("Registrazione fallita");
			}
			catch(DBConnectionException e)
			{
				System.out.println(e.getMessage());
				System.out.println("Registrazione fallita");
			}
		}
		catch(Exception e)
		{
			System.out.println("UnknownError...");
		}
	}

	public static void ricercaAvanzata()
	{
		String Paese = null;	//Stringa che può contenere sia una Città che un CAP
		int NrVani = 0;
		String Tipologia = null;
		String Email = null;
		GestioneAnnunciImmobiliari gestore=GestioneAnnunciImmobiliari.getInstance();
		boolean inputValido = false;
		
		try
		{
			while(!inputValido)
			{
				System.out.println("Inserire la citta' o il CAP:");
				Paese = scan.nextLine();
				if(isAlphabetic(Paese))
				{
					System.out.println("E' una citta'");
					if(Paese.length()<=35)
					{
						inputValido=true;
					}
					else System.out.println("Citta' troppo lunga!"); 
				}
				else if(isNumeric(Paese))
				{
					System.out.println("E' un CAP");
					if(Paese.length()==5)
					{
						inputValido=true;
					}
					else System.out.println("CAP di dimensioni non valide!");
				}
				else System.out.println("Paese errato!");
			}
			inputValido=false;
			while(!inputValido)
			{
				try
				{
					System.out.println("Inserire il numero di vani:");
					NrVani = Integer.parseInt(scan.nextLine());
					if(NrVani>0)
						inputValido=true;
					else System.out.println("Numero di vani non valido!");
				}
				catch(NumberFormatException e)
				{
					System.out.println("Errore nell'inserimento del numero di vani, riprovare..");
					System.out.println();
				}
			}
			inputValido=false;
			while(!inputValido)
			{
				System.out.println("Inserire la tipologia:");
				Tipologia=scan.nextLine();
				if(Tipologia.equals("Affitto")||Tipologia.equals("Vendita"))
					inputValido=true;
				else System.out.println("Tipologia non valida...");
			}
			
			
			inputValido=false;
			while(!inputValido)
			{
				System.out.println("Inserire la mail di registrazione:");
				Email = scan.nextLine();
				if (Email.contains("@") && Email.contains(".")) {
					inputValido = true;
				} else {
					System.out.println("Email non valida..");
				}
			}
			ArrayList<EntityAnnuncio> Lista = gestore.ricercaAnnunci(Paese, NrVani, Tipologia, Email);
			visualizzaLista(Lista);
		} catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
	
	private static boolean isAlphabetic(String str)
	{
	    return str.matches("[a-zA-Z ]+");
	}
	
	public static boolean isNumeric(String str)
	{
		  return str.matches("[0-9]+");
	}
	
	private static void visualizzaLista(ArrayList<EntityAnnuncio> Lista) throws EmptyListException
	{
		GestioneAnnunciImmobiliari gestore=GestioneAnnunciImmobiliari.getInstance();
		gestore.visualizzaDettagliLista(Lista);
	}
	
}