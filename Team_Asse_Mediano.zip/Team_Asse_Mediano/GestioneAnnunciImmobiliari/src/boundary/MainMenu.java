package boundary;

import java.util.Scanner;

public class MainMenu
{
	
	static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args)
	{
		String comando = null;
		boolean login = false;
		boolean execution=true;
		while(execution)
		{
			System.out.println("Vuoi accedere come utente o come inserzionista?");
			System.out.println("1: Utente");
			System.out.println("2: Inserzionista");
			System.out.println("3: Close");
			comando = scan.nextLine();
			switch(comando)
			{
			case "1":
				System.out.println("Hai fatto l'accesso come utente");
				String comandoUtente= null;
				login=true;
				while(login)
				{
					System.out.println("Quale comando vuoi avviare?");
					System.out.println("1: Registrazione Utente");
					System.out.println("2: Ricerca Annuncio");
					System.out.println("3: Logout");
					comandoUtente=scan.nextLine();
					switch(comandoUtente)
					{
					case "1":
						BoundaryUtente.registrazioneUtente();
						break;
					case "2":
						BoundaryUtente.ricercaAvanzata();
						break;
					case "3":
						login=false;
						System.out.println("Logout effettuato!");
						break;
					default:
						System.out.println("Comando non valido, riprovare...");
					}
				}
				break;
			case "2":
				System.out.println("Hai fatto l'accesso come inserzionista");
				String comandoInserzionista=null;
				login=true;
				System.out.println("Quale comando vuoi avviare?");
				System.out.println("1: Pubblicazione annuncio");
				System.out.println("2: Logout");
				comandoInserzionista=scan.nextLine();
				switch(comandoInserzionista)
				{
				case "1":
					BoundaryInserzionista.pubblicazioneAnnuncio();
					break;
				case "2":
					login=false;
					System.out.println("Logout effettuato");
					break;
				default:
					System.out.println("Comando non valido, riprovare...");
				}
				break;
			case "3":
				System.out.println("Chiusura del software in corso...");
				execution=false;
				System.out.println("Chiusura del software effettuata con successo!");
				break;
			default:
				System.out.println("Inserimento non valido, riprovare...");
			}
		}
	}
}