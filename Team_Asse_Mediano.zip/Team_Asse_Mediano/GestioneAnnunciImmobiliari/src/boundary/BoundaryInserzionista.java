package boundary;

import java.util.ArrayList;
import java.util.Scanner;

import exception.OperationException;
import control.GestioneAnnunciImmobiliari;
import entity.EntityAnnuncio;
import entity.EntityFoto;

public class BoundaryInserzionista
{
	static Scanner scan = new Scanner(System.in);
	static String Username = "Bruno";
	
	public static String getUsername(){return Username;}
	
	public static void pubblicazioneAnnuncio()
	{
		String Tipologia = null;
		String Città = null;
		String CAP = null;
		float NrMetriQuadri = 0;
		int NrVani = 0;
		String Stato = null;
		float Prezzo = 0;
		String Descrizione = null;
		ArrayList<EntityFoto> Fotografie = null;
		boolean inputValido = false;
		GestioneAnnunciImmobiliari gestioneAnnunciImmobiliari=GestioneAnnunciImmobiliari.getInstance();
		
		try
		{
			while(!inputValido)
			{
				System.out.println("Inserire la tipologia:");
				Tipologia=scan.nextLine();
				if(Tipologia.equals("Affitto")||Tipologia.equals("Vendita"))
					inputValido=true;
				else System.out.println("Tipologia non valida...");
			}
			inputValido=false;
			while(!inputValido)
			{
				System.out.println("Inserire la citta':");
				Città=scan.nextLine();
				if(Città.length()<=35)
					if(isAlphabetic(Città))
						inputValido=true;
					else System.out.println("Citta' non valida!");
				else System.out.println("Citta' troppo lunga!");
			}
			inputValido=false;
			while(!inputValido)
			{
				try
				{
					System.out.println("Inserire il CAP:");
					CAP = scan.nextLine();
					if(CAP.length()==5&&isNumeric(CAP))
						inputValido=true;
					else System.out.println("CAP non valido!");
				}
				catch(NumberFormatException e)
				{
					System.out.println("Errore nell'acquisizione del CAP, riprovare..");
					System.out.println();
				}
			}
			inputValido=false;
			while(!inputValido)
			{
				try
				{
					System.out.println("Inserire il numero di metri quadri:");
					NrMetriQuadri = Float.parseFloat(scan.nextLine());
					if(NrMetriQuadri>0)
						inputValido=true;
					else System.out.println("Numero di metri quadri non valido!");
				}
				catch(NumberFormatException e)
				{
					System.out.println("Errore nell'acquisizione del numero di metri quadri, riprovare..");
					System.out.println();
				}
			}
			inputValido=false;
			while(!inputValido)
			{
				try
				{
					System.out.println("Inserire il numero di vani:");
					NrVani = Integer.parseInt(scan.nextLine());
					if(NrVani>0)
						inputValido=true;
					else System.out.println("numero di vani non valido!");
				}
				catch(NumberFormatException e)
				{
					System.out.println("Errore nell'acquisizione del numero di vani, riprovare..");
					System.out.println();
				}
			}
			inputValido=false;
			while(!inputValido)
			{
				System.out.println("Inserire lo stato:");
				Stato=scan.nextLine();
				if(Stato.length()<=30)
					if(isAlphabetic(Stato))
						inputValido=true;
					else System.out.println("Stato non valido!");
				else System.out.println("Stato troppo lungo!");
			}
			inputValido=false;
			while(!inputValido)
			{
				try
				{
					System.out.println("Inserire il prezzo:");
					Prezzo = Float.parseFloat(scan.nextLine());
					if(Prezzo>0)
						inputValido=true;
					else System.out.println("Prezzo non valido!");
				}
				catch(NumberFormatException e)
				{
					System.out.println("Errore nell'acquisizione del numero di metri quadri, riprovare..");
					System.out.println();
				}
			}
			inputValido=false;
			while(!inputValido)
			{
				System.out.println("Inserire la descrizione:");
				Descrizione=scan.nextLine();
				if(Descrizione.length()<=500)
					inputValido=true;
				else System.out.println("Descrizione troppo lunga!");
			}
			EntityAnnuncio eA=gestioneAnnunciImmobiliari.inserisciDatiAnnuncio(Tipologia, Città, CAP, NrMetriQuadri, NrVani, Stato, Prezzo, Descrizione);
			Fotografie=initListaFotografie(eA);
			
			System.out.println("Vuoi confermare la pubblicazione?");
			System.out.println("S: si'");
			String conferma = scan.nextLine();
			if (!conferma.equals("S") && !conferma.equals("s"))
			{
				System.out.println("Operazione annullata..");
				System.out.println();
				return;
			}
			gestioneAnnunciImmobiliari.confermaPubblicazione(eA, Fotografie);
			System.out.println("Pubblicazione effettuata!");
		}
		catch (Exception e)
		{
			e.getMessage();
		}
	}
	
	private static boolean isAlphabetic(String str) {
	    return str.matches("[a-zA-Z ]+");
	}
	
	
	private static ArrayList<EntityFoto> initListaFotografie(EntityAnnuncio annuncio) throws OperationException
	{
		ArrayList<EntityFoto> Lista=new ArrayList<EntityFoto>();
		int dim=0;
		String Url=null;
		boolean dimValida=false;
		
		try
		{
		while(!dimValida)
		{
			System.out.println("Inserire dimensione della lista di fotografie:");
			dim=Integer.parseInt(scan.nextLine());
			if(dim>0 && dim<9)
				dimValida=true;
			else System.out.println("Dimensione lista non valida!");
		}
		for (int i=0;i<dim;i++)
		{
			System.out.println("Inserire URL numero "+i);
			Url=scan.nextLine();
			Lista.add(new EntityFoto(Url, annuncio));
		}
		return Lista;
		}
		catch(NumberFormatException e)
		{
			throw new OperationException("Errore nell'inserimento");
		}
	}
	
	public static boolean isNumeric(String str)
	{
		  return str.matches("[0-9]+");
	}
}