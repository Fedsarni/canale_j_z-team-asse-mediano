-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 21, 2023 at 10:49 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DatabaseAnnunciImmobiliari`
--

-- --------------------------------------------------------

--
-- Table structure for table `Annunci`
--

CREATE TABLE `Annunci` (
  `Identificativo` int(11) NOT NULL,
  `NrMetriQuadri` float NOT NULL,
  `NrVani` int(11) NOT NULL,
  `Stato` varchar(30) NOT NULL,
  `Prezzo` float NOT NULL,
  `CAP` varchar(5) NOT NULL,
  `Citta'` varchar(35) NOT NULL,
  `Tipologia` enum('Vendita','Affitto') NOT NULL,
  `Descrizione` text NOT NULL,
  `DataInserimento` date NOT NULL,
  `UsernameInserzionista` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Annunci`
--

INSERT INTO `Annunci` (`Identificativo`, `NrMetriQuadri`, `NrVani`, `Stato`, `Prezzo`, `CAP`, `Citta'`, `Tipologia`, `Descrizione`, `DataInserimento`, `UsernameInserzionista`) VALUES
(13, 68.5, 3, 'Nuovo', 80000, '80013', 'Napoli', 'Vendita', 'Nuovo', '2023-07-19', 'Bruno'),
(14, 54, 1, 'Nuovo', 56568, '80016', 'Napoli', 'Vendita', 'Nuovo', '2023-07-19', 'Bruno'),
(15, 87, 3, 'Nuovo', 120000, '80016', 'Napoli', 'Affitto', 'Nuovo', '2023-07-19', 'Bruno'),
(16, 73, 1, 'Integro', 96842, '80016', 'Napoli', 'Vendita', 'In ottime condizioni', '2023-07-19', 'Bruno'),
(17, 85, 5, 'Da ristrutturare', 400000, '80131', 'Marano di Napoli', 'Affitto', 'Fatti dei tuoi se vuoi comprare casa a Marano', '2023-07-19', 'Bruno'),
(18, 67, 3, 'Nuovo', 456573, '80014', 'Napoli', 'Affitto', 'Costruito tanto tempo fa', '2023-07-21', 'Bruno'),
(19, 324, 4, 'Ristrutturato', 989823, '80034', 'Vomero', 'Affitto', 'Serve per prova', '2023-07-21', 'Bruno');

-- --------------------------------------------------------

--
-- Table structure for table `Fotografie`
--

CREATE TABLE `Fotografie` (
  `Id` int(11) NOT NULL,
  `URL` varchar(100) NOT NULL,
  `IdAnnuncio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Fotografie`
--

INSERT INTO `Fotografie` (`Id`, `URL`, `IdAnnuncio`) VALUES
(17, 'sdcsdvs', 13),
(18, 'cssdfscx', 13),
(19, 'aerscdxv', 13),
(20, 'sfdvwreg', 14),
(21, 'dsdcs', 15),
(22, 'vdfve', 15),
(23, 'asdaewc', 16),
(24, 'dgfhfnb', 17),
(25, 'gdfgdvsr', 17),
(26, 'ohjkhnu', 17),
(27, 'sdscvd', 17),
(28, 'rbvtfhg', 17),
(29, 'vdv', 18),
(30, 'fdscsdf', 18),
(31, 'ascsdcd', 18),
(32, 'VSDVDSV', 18),
(33, 'Sfsdfs', 19);

-- --------------------------------------------------------

--
-- Table structure for table `Inserzionisti`
--

CREATE TABLE `Inserzionisti` (
  `Username` varchar(30) NOT NULL,
  `Password` varchar(16) NOT NULL,
  `RecapitoEmail` varchar(30) NOT NULL,
  `RepapitoTelefonico` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Inserzionisti`
--

INSERT INTO `Inserzionisti` (`Username`, `Password`, `RecapitoEmail`, `RepapitoTelefonico`) VALUES
('Bruno', 'bruno', 'brunoruggiero@gmail.com', '3395466531'),
('Federica', 'federica', 'fedesarnataro@gmail.com', '4210'),
('Francesco', 'francesco', 'francescotafuri@gmail.com', '5678');

-- --------------------------------------------------------

--
-- Table structure for table `UtentiRegistrati`
--

CREATE TABLE `UtentiRegistrati` (
  `Email` varchar(30) NOT NULL,
  `Cognome` varchar(15) NOT NULL,
  `Nome` varchar(15) NOT NULL,
  `NrTelefono` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `UtentiRegistrati`
--

INSERT INTO `UtentiRegistrati` (`Email`, `Cognome`, `Nome`, `NrTelefono`) VALUES
('brunoruggiero@gmail.com', 'Ruggiero', 'Bruno', '3395466531'),
('fedesarnataro@gmail.com', 'Sarnataro', 'Federica', '4355643633');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Annunci`
--
ALTER TABLE `Annunci`
  ADD PRIMARY KEY (`Identificativo`),
  ADD KEY `UsernameInserzionista` (`UsernameInserzionista`);

--
-- Indexes for table `Fotografie`
--
ALTER TABLE `Fotografie`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IdAnnuncio` (`IdAnnuncio`);

--
-- Indexes for table `Inserzionisti`
--
ALTER TABLE `Inserzionisti`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `UtentiRegistrati`
--
ALTER TABLE `UtentiRegistrati`
  ADD PRIMARY KEY (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Annunci`
--
ALTER TABLE `Annunci`
  MODIFY `Identificativo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `Fotografie`
--
ALTER TABLE `Fotografie`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Annunci`
--
ALTER TABLE `Annunci`
  ADD CONSTRAINT `FK_USERNAME` FOREIGN KEY (`UsernameInserzionista`) REFERENCES `Inserzionisti` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Fotografie`
--
ALTER TABLE `Fotografie`
  ADD CONSTRAINT `FK_ID` FOREIGN KEY (`IdAnnuncio`) REFERENCES `Annunci` (`Identificativo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
